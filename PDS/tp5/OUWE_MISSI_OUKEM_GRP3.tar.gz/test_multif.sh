#!/bin/bash

echo "Les deux premiers arguments concernent la fonction isPair le dernier argument concerne la commande isPos"
echo "isPair est réussi si l'argument passé en paramètre est pair et isPos est réussi si l'argument passé en paramètre est positif"
echo "Multif avec 2 2 2"
./multif 2 2 2
echo "Multif avec 1 2 2"
./multif 1 2 2
echo "Multif avec 2 2 -5"
./multif 2 2 -5
