package jade;
public interface JadeMachine {
    
    /**
     * 
     * n > 0
     *longueur du pas
     */
    public void setStepLength(int n);

    /**
     * fixer le mode crayon true = activé
     */
    public void setPenMode(boolean active);
    
    /**
     * mouvement dans la direction donnée
     * trace un trait si crayon activé
     *
     */
    public void move(Direction d);
 
    /**
     * positionne le crayon sur le point de coord x,y
     */
    public void jump(int x, int y);

    /**
     * stopper la machine.
     *
     */
    public void stop(int x, int y);





}

