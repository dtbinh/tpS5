package jade;

import drawing.DrawingException;
import drawing.DrawingFrame;
import java.awt.Point;

public class DrawingMachine extends DrawingFrame implements JadeMachine {

    private int stepLength = 5;
    private boolean penMode = false;

    public DrawingMachine() {
	super();
	this.reset();
    }

    public void setStepLength(int n) {
	this.stepLength = n;
    }

    public void setPenMode(boolean active) {
	this.penMode = active;
    }

    public void move(Direction d) {
	Point p = this.getCurrentPoint();
	p.setLocation(p.getX() + this.stepLength * d.getX(), p.getY() + this.stepLength * d.getY());
	try {
	    if (this.penMode)
		this.drawTo(p);
	    else
		this.goTo(p);
	} catch (DrawingException e) {
	    System.out.println("*** Coordonnées de destination incorrectes ***");
	}
    }

    public void jump(int x, int y) {
	try {
	    this.goTo(new Point(x, y));
	} catch (DrawingException e) {
	    System.out.println("*** Coordonnées de destination incorrectes ***");
	}
    }

    public void stop(int x, int y) {
	this.stepLength = 5;
	this.penMode = false;
	this.jump(x, y);
    }
}
