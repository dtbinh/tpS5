package jadelex;

public class Jump extends BaseToken {
    
    private int x, y;	
    
    public Jump(String x, String y){
        super(TokenType.JUMP);
	this.x = Integer.parseInt(x);
	this.y = Integer.parseInt(y);
    }
    
    public int getX() {
        return this.x;
    }

    public int getY() {
	return this.y;
    }
    
    public String toString(){
        return super.toString()+"["+this.x+", "+this.y+"]";
    }
    
}
