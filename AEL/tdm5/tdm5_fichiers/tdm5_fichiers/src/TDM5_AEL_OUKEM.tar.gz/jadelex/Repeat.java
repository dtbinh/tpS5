package jadelex;

public class Repeat extends BaseToken {
    
    private int cpt;
    
    public Repeat(String occurences) {
        super(TokenType.REPEAT);
	cpt = Integer.parseInt(occurences);
    }
    
    public int getOccurences() {
        return this.occurences;
    }
    
    public String toString(){
        return super.toString()+"["+this.cpt+"]";
    }
    
}
