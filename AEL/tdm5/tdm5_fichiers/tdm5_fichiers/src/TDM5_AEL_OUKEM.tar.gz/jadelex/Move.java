package jadelex;

import jade.Direction;

public class Move extends BaseToken {
    
    private Direction direction;
    
    public Move(String direction){
        super(TokenType.MOVE);
	switch (direction) {
	case "nord":
	    this.direction = Direction.NORTH;
	    break;
	case "sud":
	    this.direction = Direction.SOUTH;
	    break;
	case "est":
	    this.direction = Direction.EAST;
	    break;
	default:
	    this.direction = Direction.WEST;
	    break;
	}
    }
    
    public Direction getDirection() {
        return this.direction;
    }
    
    public String toString(){
        return super.toString()+"["+this.direction+"("+this.direction.getX()+","+this.direction.getY()+")]";
    }
    
}
