package jadelex;

/**
 *  YYtoken implementation for PEN_MODE token type
 */

public class PenMode extends BaseToken{
    private boolean write;
    
    public boolean getMode(){
        return write;
    }
    public PenMode(boolean on){
        super(TokenType.PEN_MODE);
        this.write = on;
    }
    public String toString(){
        return super.toString()+"["+write+"]";
    }
}