package jadelex;
import java.io.*;
class Test {
  
  
  public static void main(String arg[]) throws IOException {
     
    Reader read;

    if (arg.length>0){
      read = new BufferedReader(new FileReader(arg[0]));
    }
    else {
      read = new InputStreamReader(System.in);
    }
    Tokenizer yy = new TokenizerV1(read) ;
    Yytoken token ;
    while ((token = yy.yylex()) != null){
      //System.out.print("["+token.image()+"]<"+token.nom()+">");
      System.out.print(token);
    }
    System.out.println();
  }
}
