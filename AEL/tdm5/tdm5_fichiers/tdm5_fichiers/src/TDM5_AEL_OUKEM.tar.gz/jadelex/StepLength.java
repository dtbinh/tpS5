package jadelex;

public class StepLength extends BaseToken {
    
    private int length;
    
    public StepLength(String length){
        super(TokenType.STEP_LENGTH);
	this.length = Integer.parseInt(length);
    }
    
    public int getLength() {
        return this.length;
    }
    
    public String toString(){
        return super.toString()+"["+this.length+"]";
    }
    
}
